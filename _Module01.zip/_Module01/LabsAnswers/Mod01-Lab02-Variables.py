# ------------------------------------------------------------------------------------------ #
# Title: Mod01-Lab01-Variables
# Desc: This lab demonstrates how to create a use variables
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   <Your Name Here>,<Date>, <Activity>
# ------------------------------------------------------------------------------------------ #
"""
* Create variables with descriptive names
* Use the print() function to display the student's full name
"""

student_first_name_str = "Vic"
student_last_name_str = "Vu"
print(student_first_name_str, student_last_name_str)
